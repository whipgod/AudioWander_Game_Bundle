import wx
from score import get_high_scores
from utils import set_default_font, play_music

class HighScoresDialog(wx.Dialog):
    def __init__(self, parent):
        super().__init__(parent, title="High Scores", size=(400, 300))
        self.parent = parent

        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)

        self.games = ["dice", "guess", "rps", "math"]
        self.choice = wx.Choice(panel, choices=[g.capitalize() for g in self.games])
        set_default_font(self.choice)
        self.choice.SetSelection(0)
        self.choice.Bind(wx.EVT_CHOICE, self.update_scores)
        vbox.Add(self.choice, 0, wx.ALL | wx.EXPAND, 10)

        self.text = wx.TextCtrl(panel, style=wx.TE_MULTILINE | wx.TE_READONLY)
        set_default_font(self.text)
        vbox.Add(self.text, 1, wx.ALL | wx.EXPAND, 10)

        close_btn = wx.Button(panel, label="Close")
        set_default_font(close_btn)
        close_btn.Bind(wx.EVT_BUTTON, self.on_close)
        vbox.Add(close_btn, 0, wx.ALL | wx.ALIGN_CENTER, 5)

        panel.SetSizer(vbox)
        self.update_scores()
        self.Centre()
        self.ShowModal()

    def update_scores(self, event=None):
        game = self.games[self.choice.GetSelection()]
        scores = get_high_scores(game)
        if not scores:
            self.text.SetValue("No scores yet.")
        else:
            lines = [f"{i+1}. {entry['name']} - {entry['score']}" for i, entry in enumerate(scores)]
            self.text.SetValue("\n".join(lines))

    def on_close(self, event):
        self.Destroy()
        if self.parent:
            self.parent.Show()
            play_music("menu")
