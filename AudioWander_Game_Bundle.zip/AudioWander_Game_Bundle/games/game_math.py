import wx
import random
import time
from utils import speak, play, play_music, stop_music, set_default_font, create_announce_label
from score import save_score

TOTAL_QUESTIONS = 40
TIME_LIMITS = [(1, 10, 20000), (11, 20, 15000), (21, 30, 10000), (31, 40, 6000)]
MAX_WRONG_IN_ROW = 5

class GameMath(wx.Frame):
    def __init__(self, parent):
        super().__init__(parent, title="Math Challenge", size=(400, 300))
        self.parent = parent
        self.correct_answers = 0
        self.current_question = 0
        self.wrong_in_row = 0
        self.total_questions_asked = 0

        panel = wx.Panel(self)
        self.vbox = wx.BoxSizer(wx.VERTICAL)

        self.announce_label = create_announce_label(panel)
        self.vbox.Add(self.announce_label, 0, wx.EXPAND | wx.ALL, 5)

        self.label = wx.StaticText(panel, label="Answer 40 math questions. Good luck!")
        set_default_font(self.label)
        self.vbox.Add(self.label, 0, wx.ALL | wx.ALIGN_CENTER, 15)

        self.input = wx.TextCtrl(panel, style=wx.TE_PROCESS_ENTER)
        set_default_font(self.input)
        self.vbox.Add(self.input, 0, wx.ALL | wx.EXPAND, 10)
        self.input.Bind(wx.EVT_TEXT_ENTER, self.on_answer)
        self.input.Hide()

        self.start_btn = wx.Button(panel, label="Start Game")
        set_default_font(self.start_btn)
        self.start_btn.Bind(wx.EVT_BUTTON, self.start_game)
        self.vbox.Add(self.start_btn, 0, wx.ALL | wx.EXPAND, 8)

        back = wx.Button(panel, label="Back to Menu")
        set_default_font(back)
        back.Bind(wx.EVT_BUTTON, self.on_back)
        self.vbox.Add(back, 0, wx.ALL | wx.EXPAND, 8)

        panel.SetSizer(self.vbox)
        self.Centre()
        self.Show()

        play_music("math")
        speak("Welcome to Math Challenge. You must answer 40 math questions. "
              "From question 1 to 10 you have 20 seconds, "
              "11 to 20 you have 15 seconds, "
              "21 to 30 you have 10 seconds, and "
              "31 to 40 you have 6 seconds. "
              "If you fail 5 times in a row, you lose.", self.announce_label, clear=True)

    def start_game(self, event):
        self.start_btn.Disable()
        self.input.Show()
        self.input.SetFocus()
        self.ask_question()

    def get_time_limit(self):
        for start, end, limit in TIME_LIMITS:
            if start <= self.current_question <= end:
                return limit
        return 6000

    def ask_question(self):
        self.current_question += 1
        self.total_questions_asked += 1

        if self.current_question > TOTAL_QUESTIONS:
            speak("You completed all questions!", self.announce_label, clear=True)
            play("correct", True)
            self.ask_name_and_save()
            return

        op = random.choice(["+", "-", "*", "/"])
        if op == "+":
            a, b = random.randint(10, 99), random.randint(10, 99)
            self.answer = a + b
            self.question = f"{a} plus {b}"
        elif op == "-":
            a, b = random.randint(10, 99), random.randint(10, 99)
            self.answer = a - b
            self.question = f"{a} minus {b}"
        elif op == "*":
            a, b = random.randint(1, 9), random.randint(1, 9)
            self.answer = a * b
            self.question = f"{a} multiplied by {b}"
        else:
            b = random.randint(2, 9)
            self.answer = random.randint(2, 12)
            a = self.answer * b
            self.question = f"{a} divided by {b}"

        speak(self.question, self.announce_label, clear=True)
        self.start_time = time.time()
        self.timeout = self.get_time_limit()
        self.timer_id = wx.CallLater(self.timeout, self.check_timeout)
        self.input.SetFocus()

    def on_answer(self, event):
        if hasattr(self, 'timer_id') and self.timer_id.IsRunning():
            self.timer_id.Stop()

        try:
            user_answer = int(self.input.GetValue().strip())
        except:
            user_answer = None

        self.input.Clear()

        if user_answer == self.answer:
            self.correct_answers += 1
            self.wrong_in_row = 0
            self.ask_question()
        else:
            speak("Incorrect.", self.announce_label, clear=True)
            play("false")
            self.wrong_in_row += 1
            if self.wrong_in_row >= MAX_WRONG_IN_ROW:
                self.fail_game()
            else:
                self.ask_question()

    def check_timeout(self):
        speak("Time's up.", self.announce_label, clear=True)
        play("false")
        self.wrong_in_row += 1
        if self.wrong_in_row >= MAX_WRONG_IN_ROW:
            self.fail_game()
        else:
            self.ask_question()

    def fail_game(self):
        speak(f"You lost. You answered {self.correct_answers} correctly. Returning to main menu.", self.announce_label, clear=True)
        play("wrong_answer", True)
        self.ask_name_and_save()

    def ask_name_and_save(self):
        dlg = wx.TextEntryDialog(self, "Enter your name for the high score list:", "Game Over", "You")
        name = "You"
        if dlg.ShowModal() == wx.ID_OK:
            name = dlg.GetValue().strip() or "You"
        dlg.Destroy()
        save_score("math", name, self.correct_answers)
        self.on_back(None)

    def on_back(self, event):
        stop_music()
        self.Destroy()
        self.parent.Show()
        play_music("menu")
