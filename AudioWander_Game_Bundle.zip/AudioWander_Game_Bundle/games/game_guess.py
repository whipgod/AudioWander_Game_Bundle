# games/game_guess.py
import wx
import random
from utils import speak, play, play_music, stop_music, set_default_font, create_announce_label
from score import save_score

GUESS_RANGE = (1, 100)

class GameGuess(wx.Frame):
    def __init__(self, parent):
        super().__init__(parent, title="Guess the Number", size=(400, 300))
        self.parent = parent
        self.secret = random.randint(*GUESS_RANGE)
        self.tries = 0

        panel = wx.Panel(self)
        self.announce_label = create_announce_label(panel)
        self.vbox = wx.BoxSizer(wx.VERTICAL)
        self.vbox.Add(self.announce_label, 0, wx.EXPAND | wx.ALL, 5)

        self.label = wx.StaticText(panel, label="I'm thinking of a number between 1 and 100.")
        set_default_font(self.label)
        self.vbox.Add(self.label, 0, wx.ALL | wx.ALIGN_CENTER, 15)

        self.input = wx.TextCtrl(panel)
        set_default_font(self.input)
        self.vbox.Add(self.input, 0, wx.ALL | wx.EXPAND, 10)

        guess_btn = wx.Button(panel, label="Guess")
        set_default_font(guess_btn)
        guess_btn.Bind(wx.EVT_BUTTON, self.check_guess)
        self.vbox.Add(guess_btn, 0, wx.ALL | wx.EXPAND, 8)

        back = wx.Button(panel, label="Back to Menu")
        set_default_font(back)
        back.Bind(wx.EVT_BUTTON, self.on_back)
        self.vbox.Add(back, 0, wx.ALL | wx.EXPAND, 8)

        panel.SetSizer(self.vbox)
        self.Centre()
        self.Show()
        play_music("guess")
        speak("Guess the Number started. Enter your guess.", self.announce_label, clear=True)

    def check_guess(self, event):
        try:
            guess = int(self.input.GetValue())
        except:
            speak("Invalid input.", self.announce_label, clear=True)
            return

        self.tries += 1
        if guess < self.secret:
            speak("Too low.", self.announce_label)
            play("wrong_low")
        elif guess > self.secret:
            speak("Too high.", self.announce_label)
            play("wrong_high")
        else:
            speak(f"Correct! You found it in {self.tries} tries.", self.announce_label, clear=True)
            play("correct", True)
            play("win", True)
            self.ask_name_and_save()

    def ask_name_and_save(self):
        dlg = wx.TextEntryDialog(self, "Enter your name for the high score list:", "Victory!", "You")
        if dlg.ShowModal() == wx.ID_OK:
            name = dlg.GetValue().strip() or "You"
        else:
            name = "You"
        dlg.Destroy()
        save_score("guess", name, self.tries)
        wx.CallLater(1500, self.return_to_menu)

    def return_to_menu(self):
        self.Destroy()
        self.parent.Show()
        play_music("menu")

    def on_back(self, event):
        stop_music()
        self.Destroy()
        self.parent.Show()
        play_music("menu")
