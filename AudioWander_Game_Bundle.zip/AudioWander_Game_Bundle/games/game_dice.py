# games/game_dice.py
import wx
import random
from utils import speak, play, play_music, stop_music, set_default_font, create_announce_label
from score import save_score

DICE_RACE_TARGET_SCORE = 50

class GameDice(wx.Frame):
    def __init__(self, parent):
        super().__init__(parent, title="Dice Race", size=(400, 300))
        self.parent = parent
        self.score = [0, 0]
        self.turn = 0

        panel = wx.Panel(self)
        self.announce_label = create_announce_label(panel)
        self.vbox = wx.BoxSizer(wx.VERTICAL)
        self.vbox.Add(self.announce_label, 0, wx.EXPAND | wx.ALL, 5)

        self.label = wx.StaticText(panel, label="First to 50 wins. Your turn.")
        set_default_font(self.label)
        self.vbox.Add(self.label, 0, wx.ALL | wx.ALIGN_CENTER, 15)

        self.roll_btn = wx.Button(panel, label="Roll Dice")
        set_default_font(self.roll_btn)
        self.roll_btn.Bind(wx.EVT_BUTTON, self.roll_dice)
        self.vbox.Add(self.roll_btn, 0, wx.ALL | wx.EXPAND, 8)

        back = wx.Button(panel, label="Back to Menu")
        set_default_font(back)
        back.Bind(wx.EVT_BUTTON, self.on_back)
        self.vbox.Add(back, 0, wx.ALL | wx.EXPAND, 8)

        panel.SetSizer(self.vbox)
        self.Centre()
        self.Show()
        play_music("dice")
        speak("Dice Race started. First to 50 wins. Your turn.", self.announce_label, clear=True)

    def roll_dice(self, event):
        if self.turn % 2 != 0:
            speak("It's not your turn.", self.announce_label, clear=True)
            return

        roll = random.randint(1, 6)
        play("dice_roll", True)
        self.score[0] += roll
        speak(f"You rolled {roll}. Your score is {self.score[0]}", self.announce_label, clear=True)

        if self.score[0] >= DICE_RACE_TARGET_SCORE:
            self.end_game("You")
            return

        if roll == 6:
            speak("You rolled a 6 and get an extra turn.", self.announce_label)
        else:
            self.turn += 1
            wx.CallLater(1500, self.computer_turn)

    def computer_turn(self):
        roll = random.randint(1, 6)
        play("dice_roll", True)
        self.score[1] += roll
        speak(f"Computer rolled {roll}. Score is {self.score[1]}", self.announce_label, clear=True)

        if self.score[1] >= DICE_RACE_TARGET_SCORE:
            self.end_game("Computer")
            return

        if roll == 6:
            speak("Computer rolled a 6 and gets an extra turn.", self.announce_label)
            wx.CallLater(1500, self.computer_turn)
        else:
            self.turn += 1
            speak("Your turn.", self.announce_label)

    def end_game(self, winner):
        speak(f"{winner} won the game with 50 points!", self.announce_label, clear=True)
        play("cheer", True)
        self.roll_btn.Disable()

        if winner == "You":
            self.ask_name_and_save()
        else:
            save_score("dice", "Computer", self.score[1])

        wx.CallLater(2000, self.return_to_menu)

    def ask_name_and_save(self):
        dlg = wx.TextEntryDialog(self, "Enter your name for the high score list:", "Victory!", "You")
        if dlg.ShowModal() == wx.ID_OK:
            name = dlg.GetValue().strip() or "You"
        else:
            name = "You"
        dlg.Destroy()
        save_score("dice", name, self.score[0])

    def return_to_menu(self):
        self.Destroy()
        self.parent.Show()
        play_music("menu")

    def on_back(self, event):
        stop_music()
        self.Destroy()
        self.parent.Show()
        play_music("menu")
