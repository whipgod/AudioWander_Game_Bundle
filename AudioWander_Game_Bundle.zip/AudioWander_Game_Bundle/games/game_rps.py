# games/game_rps.py
import wx
import random
from utils import speak, play, play_music, stop_music, set_default_font, create_announce_label
from score import save_score

RPS_WIN_SCORE = 5

class GameRPS(wx.Frame):
    def __init__(self, parent):
        super().__init__(parent, title="Rock Paper Scissors", size=(400, 300))
        self.parent = parent
        self.score = [0, 0]
        self.choices = ["Rock", "Paper", "Scissors"]

        panel = wx.Panel(self)
        self.announce_label = create_announce_label(panel)
        self.vbox = wx.BoxSizer(wx.VERTICAL)
        self.vbox.Add(self.announce_label, 0, wx.EXPAND | wx.ALL, 5)

        self.label = wx.StaticText(panel, label="First to 5 wins.")
        set_default_font(self.label)
        self.vbox.Add(self.label, 0, wx.ALL | wx.ALIGN_CENTER, 15)

        for i, name in enumerate(self.choices):
            btn = wx.Button(panel, label=name)
            set_default_font(btn)
            btn.Bind(wx.EVT_BUTTON, lambda e, i=i: self.play_round(i))
            self.vbox.Add(btn, 0, wx.ALL | wx.EXPAND, 8)

        back = wx.Button(panel, label="Back to Menu")
        set_default_font(back)
        back.Bind(wx.EVT_BUTTON, self.on_back)
        self.vbox.Add(back, 0, wx.ALL | wx.EXPAND, 8)

        panel.SetSizer(self.vbox)
        self.Centre()
        self.Show()
        play_music("rps")
        speak("Rock Paper Scissors started. First to 5 wins.", self.announce_label, clear=True)

    def play_round(self, idx):
        player_choice = self.choices[idx]
        play(player_choice.lower(), True)
        comp = random.randint(0, 2)
        comp_choice = self.choices[comp]

        speak(f"You chose {player_choice}.", self.announce_label, clear=True)
        speak(f"Computer chose {comp_choice}.", self.announce_label)

        win = (idx - comp) % 3
        if win == 1:
            self.score[0] += 1
            result = "You win this round."
        elif win == 2:
            self.score[1] += 1
            result = "Computer wins this round."
        else:
            result = "It's a tie."

        self.label.SetLabel(f"{result} Score: You {self.score[0]} - {self.score[1]}")
        speak(result, self.announce_label)

        if self.score[0] == RPS_WIN_SCORE or self.score[1] == RPS_WIN_SCORE:
            winner = "You" if self.score[0] > self.score[1] else "Computer"
            speak(f"{winner} won the game!", self.announce_label)
            play("cheer", True)
            self.save_score_and_exit(winner)

    def save_score_and_exit(self, winner):
        if winner == "You":
            dlg = wx.TextEntryDialog(self, "Enter your name for the high score list:", "Victory!", "You")
            if dlg.ShowModal() == wx.ID_OK:
                name = dlg.GetValue().strip() or "You"
            else:
                name = "You"
            dlg.Destroy()
            save_score("rps", name, self.score[0])
        else:
            save_score("rps", "Computer", self.score[1])
        wx.CallLater(1500, self.return_to_menu)

    def return_to_menu(self):
        self.Destroy()
        self.parent.Show()
        play_music("menu")

    def on_back(self, event):
        stop_music()
        self.Destroy()
        self.parent.Show()
        play_music("menu")
