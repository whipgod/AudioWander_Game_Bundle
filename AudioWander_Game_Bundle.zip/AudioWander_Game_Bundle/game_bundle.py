import os
import wx
import threading
from score import clear_scores
from utils import (
    prepare_sounds,
    cleanup_temp,
    speak,
    play,
    play_music,
    stop_music,
    set_default_font,
    create_announce_label,
)
from games.game_rps import GameRPS
from games.game_guess import GameGuess
from games.game_dice import GameDice
from games.game_math import GameMath
from highscores import HighScoresDialog

APP_TITLE = "AudioWander Game Bundle"
APP_VERSION = "1.2"
ICON_FILE = "logo.ico"

class MainMenu(wx.Frame):
    def __init__(self):
        super().__init__(None, title=f"{APP_TITLE} v{APP_VERSION}", size=(400, 320))
        if os.path.exists(ICON_FILE):
            self.SetIcon(wx.Icon(ICON_FILE))

        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)
        self.announce_label = create_announce_label(panel)
        vbox.Add(self.announce_label, 0, wx.EXPAND | wx.ALL, 5)

        title = wx.StaticText(panel, label="Select a Game")
        set_default_font(title)
        vbox.Add(title, 0, wx.ALL | wx.ALIGN_CENTER, 15)

        buttons = [
            ("Rock Paper Scissors", self.play_rps),
            ("Guess the Number", self.play_guess),
            ("Dice Race", self.play_dice),
            ("Math Challenge", self.play_math),
            ("View High Scores", self.show_high_scores),
            ("Exit", self.on_exit),
        ]
        for label, handler in buttons:
            btn = wx.Button(panel, label=label)
            set_default_font(btn)
            btn.Bind(wx.EVT_BUTTON, handler)
            vbox.Add(btn, 0, wx.ALL | wx.EXPAND, 8)

        panel.SetSizer(vbox)
        self.Centre()
        self.Hide()
        threading.Thread(target=self.intro_sequence).start()

    def intro_sequence(self):
        wx.CallAfter(self.Show)
        play("logo", True)
        play_music("menu")
        speak("Welcome to the AudioWander Game Bundle, Developed by AudioWander and Abbass Hosseini", self.announce_label, clear=True)

    def play_rps(self, event):
        stop_music()
        self.Hide()
        GameRPS(self)

    def play_guess(self, event):
        stop_music()
        self.Hide()
        GameGuess(self)

    def play_dice(self, event):
        stop_music()
        self.Hide()
        GameDice(self)

    def play_math(self, event):
        stop_music()
        self.Hide()
        GameMath(self)

    def show_high_scores(self, event):
        self.Hide()
        HighScoresDialog(self)

    def on_exit(self, event):
        stop_music()
        self.Close()

if __name__ == '__main__':
    prepare_sounds()
    app = wx.App(False)
    MainMenu()
    app.MainLoop()
    clear_scores()
    cleanup_temp()
