import json
import os

SCORE_FILE = os.path.join(os.getenv("APPDATA"), "AudioWander", "scores.json")
os.makedirs(os.path.dirname(SCORE_FILE), exist_ok=True)

def load_scores():
    if not os.path.exists(SCORE_FILE):
        return {}
    try:
        with open(SCORE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_score(game, name, score):
    name = name.strip() if name and name.strip() else "You"
    try:
        score = int(score)
    except:
        score = 0
    data = load_scores()
    if game not in data:
        data[game] = []
    data[game].append({"name": name, "score": score})
    try:
        with open(SCORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except:
        pass

def get_high_scores(game, limit=10):
    data = load_scores()
    if game not in data:
        return []
    try:
        return sorted(data[game], key=lambda x: int(x.get("score", 0)), reverse=True)[:limit]
    except:
        return data[game][:limit]

def clear_scores():
    try:
        if os.path.exists(SCORE_FILE):
            os.remove(SCORE_FILE)
    except:
        pass
