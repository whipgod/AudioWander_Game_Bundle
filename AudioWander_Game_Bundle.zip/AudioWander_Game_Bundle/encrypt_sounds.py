import os
import zipfile
from cryptography.fernet import Fernet

key = b"MYCgD2bAkImHURxJPgt-sRk3KQ4ueRY57Rdnkm3rwiA="
fernet = Fernet(key)

base_path = os.path.dirname(os.path.abspath(__file__))
sounds_path = os.path.join(base_path, "sounds")

if not os.path.exists(sounds_path):
    print("❌ پوشه sounds پیدا نشد.")
    exit(1)

files = [f for f in os.listdir(sounds_path) if os.path.isfile(os.path.join(sounds_path, f)) and f.lower().endswith(".ogg")]

if not files:
    print(" هیچ فایل .ogg پیدا نشد.")
    exit(1)

zip_file = os.path.join(base_path, "sounds.zip")
with zipfile.ZipFile(zip_file, "w", zipfile.ZIP_DEFLATED) as zipf:
    for f in files:
        zipf.write(os.path.join(sounds_path, f), arcname=f)

with open(zip_file, "rb") as f:
    data = f.read()

encrypted = fernet.encrypt(data)

with open(os.path.join(base_path, "sounds.dat"), "wb") as f:
    f.write(encrypted)

os.remove(zip_file)

print(f" sounds.dat ساخته شد با {len(files)} فایل.")
