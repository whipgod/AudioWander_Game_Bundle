import os
import sys
import zipfile
import io
import shutil
import tempfile
import pygame
import ctypes
from cryptography.fernet import Fernet
import wx

KEY = b"MYCgD2bAkImHURxJPgt-sRk3KQ4ueRY57Rdnkm3rwiA="
ENCRYPTED_FILE = "sounds.dat"
TEMP_SOUNDS = os.path.join(tempfile.gettempdir(), "audiowander_temp_sounds")
ICON_FILE = "logo.ico"

AUDIO = {
    "logo": "logo.ogg",
    "menu": "menu_music.ogg",
    "rps": "rps_music.ogg",
    "dice": "dice_music.ogg",
    "guess": "guess_music.ogg",
    "math": "math_music.ogg",
    "cheer": "cheer.ogg",
    "win": "win_sound.ogg",
    "rock": "rock.ogg",
    "paper": "paper.ogg",
    "scissors": "scissors.ogg",
    "dice_roll": "dice_roll.ogg",
    "correct": "correct.ogg",
    "wrong_high": "wrong_high.ogg",
    "wrong_low": "wrong_low.ogg",
    "wrong_answer": "wrong_ancer.ogg",
    "false": "false.ogg"
}

SOUNDS = {}

try:
    nvda = ctypes.windll.LoadLibrary(
        os.path.join(sys._MEIPASS, "nvdaControllerClient.dll") if hasattr(sys, '_MEIPASS')
        else "nvdaControllerClient.dll"
    )
except:
    nvda = None

def prepare_sounds():
    try:
        if not os.path.exists(TEMP_SOUNDS):
            os.makedirs(TEMP_SOUNDS)
        base_path = os.path.dirname(os.path.abspath(__file__))
        dat_path = os.path.join(base_path, ENCRYPTED_FILE)
        with open(dat_path, "rb") as f:
            encrypted_data = f.read()
        fernet = Fernet(KEY)
        decrypted_data = fernet.decrypt(encrypted_data)
        with zipfile.ZipFile(io.BytesIO(decrypted_data), "r") as zipf:
            zipf.extractall(TEMP_SOUNDS)
    except Exception as e:
        print("❌ خطا در رمزگشایی sounds.dat:", e)
        sys.exit(1)

    if not pygame.get_init():
        pygame.init()
    if not pygame.mixer.get_init():
        pygame.mixer.init()

    for name, file in AUDIO.items():
        path = os.path.join(TEMP_SOUNDS, file)
        if os.path.exists(path):
            try:
                SOUNDS[name] = pygame.mixer.Sound(path)
            except Exception as e:
                print(f"⚠️ خطا در بارگذاری صدا: {file} -> {e}")

    print("📦 فایل‌های لود شده:", list(SOUNDS.keys()))
    print(f"✅ {len(SOUNDS)} صدای بازی بارگذاری شد")

def cleanup_temp():
    try:
        if os.path.exists(TEMP_SOUNDS):
            shutil.rmtree(TEMP_SOUNDS, ignore_errors=True)
    except:
        pass

def speak(text, ref=None, clear=False):
    if ref:
        try:
            old = ref.GetValue() if not clear else ""
            new_text = old + ("\n" if old else "") + text
            ref.SetValue(new_text)
            ref.SetFocus()
            ref.SetInsertionPointEnd()
            ref.SetSelection(-1, -1)
        except:
            pass
    if nvda:
        try:
            nvda.nvdaController_speakText.argtypes = [ctypes.c_wchar_p]
            nvda.nvdaController_speakText.restype = ctypes.c_int
            nvda.nvdaController_speakText(text)
        except:
            pass

def play(name, wait=False):
    if name in SOUNDS:
        try:
            sound = SOUNDS[name]
            sound.play()
            if wait:
                pygame.time.wait(int(sound.get_length() * 1000))
        except:
            pass

def play_music(name):
    stop_music()
    path = os.path.join(TEMP_SOUNDS, AUDIO.get(name, ""))
    if os.path.exists(path):
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.set_volume(0.6)
            pygame.mixer.music.play(-1)
        except:
            pass

def stop_music():
    try:
        pygame.mixer.music.stop()
    except:
        pass

def set_default_font(widget):
    font = wx.Font(11, wx.FONTFAMILY_SWISS, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, False, "Segoe UI")
    widget.SetFont(font)

def create_announce_label(parent):
    ctrl = wx.TextCtrl(parent, style=wx.TE_READONLY | wx.TE_MULTILINE)
    set_default_font(ctrl)
    return ctrl
